package ar.edu.unlam.pb2.dominio;

import java.util.ArrayList;
import java.util.List;

public class ComplejoSimple extends ComplejoDeportivo {
    private List<Evento> eventos;

    public ComplejoSimple(String nombre, double areaTotal) {
        super(nombre, areaTotal);
        this.eventos = new ArrayList<>();
    }

    public void agregarEvento(Evento evento) {
        this.eventos.add(evento);
    }

    public int calcularTotalParticipantes() {
        int total = 0;
        for (Evento evento : eventos) {
            total += evento.getNumeroParticipantes();
        }
        return total;
    }

    public List<Evento> getEventos() {
        return eventos;
    }
}

