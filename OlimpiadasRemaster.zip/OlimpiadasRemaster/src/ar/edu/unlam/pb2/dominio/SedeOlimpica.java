package ar.edu.unlam.pb2.dominio;

import java.util.ArrayList;
import java.util.List;

public class SedeOlimpica {
    private List<ComplejoDeportivo> complejos;

    public SedeOlimpica() {
        this.complejos = new ArrayList<>();
    }

    public void agregarComplejo(ComplejoDeportivo complejo) {
        this.complejos.add(complejo);
    }

    public List<ComplejoDeportivo> getComplejos() {
        return complejos;
    }
}

