package ar.edu.unlam.pb2.dominio;

import java.util.*;

public class Polideportivo extends ComplejoDeportivo {
    private Map<String, Area> areas;
    private List<Evento> eventos;

    public Polideportivo(String nombre, double areaTotal) {
        super(nombre, areaTotal);
        this.areas = new HashMap<>();
        this.eventos = new ArrayList<>();
    }

    public void agregarArea(Area area) throws IndicadorAreaException {
        if (areas.containsKey(area.getIndicador())) {
            throw new IndicadorAreaException("Indicador de área ya existente");
        }
        this.areas.put(area.getIndicador(), area);
    }

    public void agregarEvento(Evento evento) {
        this.eventos.add(evento);
    }

    public Map<String, Area> getAreas() {
        return areas;
    }

    public List<Evento> getEventos() {
        return eventos;
    }

    public Map<String, String> obtenerMapaComplejo() {
        Map<String, String> mapa = new HashMap<>();
        for (Area area : areas.values()) {
            mapa.put(this.nombre, area.getIndicador());
        }
        return mapa;
    }
}
