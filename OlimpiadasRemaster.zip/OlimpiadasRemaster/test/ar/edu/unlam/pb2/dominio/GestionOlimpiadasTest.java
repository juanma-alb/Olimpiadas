package ar.edu.unlam.pb2.dominio;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import org.junit.Assert;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.assertThrows;


import java.util.List;

import org.junit.Before;



public class GestionOlimpiadasTest {
    
    private SedeOlimpica sede;
    
    @Before
	public void init () {
		this.sede = new SedeOlimpica();
	}
    
    @Test
    public void queSePuedaCrearUnComplejoSimpleEnUnaSedeOlimpica() {
        ComplejoSimple simple = new ComplejoSimple("Gimnasio A", 1000);
        sede.agregarComplejo(simple);
        assertEquals(1, sede.getComplejos().size());
    }
    
  


    @Test
    public void queSePuedaCrearUnComplejoPolideportivoConUnAreaEnUnaSedeOlimpica() throws IndicadorAreaException {
        Polideportivo poli = new Polideportivo("Polideportivo B", 5000);
        Area area = new Area("Centro", 200);
        poli.agregarArea(area);
        sede.agregarComplejo(poli);
        assertEquals(1, sede.getComplejos().size());
        assertEquals(1, poli.getAreas().size());
    }

    @Test
    public void queAlAgregarUnAreaAUnPolideportivoConIndicadorYaExistenteLanceUnaExcepcionIndicadorAreaException() throws IndicadorAreaException {
        Polideportivo poli = new Polideportivo("Polideportivo D", 7000);
        Area area1 = new Area("Centro", 200);
        Area area2 = new Area("Centro", 300);
        poli.agregarArea(area1);
        assertThrows(IndicadorAreaException.class, () -> poli.agregarArea(area2));
    }

    @Test
    public void queSePuedaAgregarUnComisarioJuezAUnEvento() throws ComisarioException {
        Evento evento = new Evento("Salto de Longitud", "2024-07-22", 3);
        Comisario comisario = new Comisario("12345678", "Juan Perez", 40, "Juez");
        evento.agregarComisario(comisario);
        assertEquals(1, evento.getComisarios().size());
    }

    @Test
    public void queAlAgregarUnComisarioJuezInexistenteLanceUnaExcepcionComisarioException() {
        Evento evento = new Evento("Salto de Altura", "2024-07-23", 4);
        assertThrows(ComisarioException.class, () -> evento.agregarComisario(null));
        
        assertTrue(evento.getComisarios().isEmpty()); // 
    }


    @Test
    public void queSePuedaCalcularElTotalDeParticipantesDeLosEventosDeUnComplejoSimple() {
        ComplejoSimple simple = new ComplejoSimple("Gimnasio E", 1200);
        Evento evento1 = new Evento("Competencia 1", "2024-07-24", 10);
        Evento evento2 = new Evento("Competencia 2", "2024-07-25", 15);
        simple.agregarEvento(evento1);
        simple.agregarEvento(evento2);
        assertEquals(25, simple.calcularTotalParticipantes());
    }

    @Test
    public void queSePuedaCalcularElPromedioDeEdadDeLosComisariosObservadoresDeUnEventoEspecifico() throws ComisarioException {
        Evento evento = new Evento("Natación 100m", "2024-07-26", 8);
        Comisario comisario1 = new Comisario("87654321", "Maria Lopez", 30, "Observador");
        Comisario comisario2 = new Comisario("87654322", "Carlos Jimenez", 50, "Observador");
        evento.agregarComisario(comisario1);
        evento.agregarComisario(comisario2);
        assertEquals(40, evento.calcularPromedioEdadObservadores());
    }

    @Test
    public void queSePuedaObtenerUnaListaDeComisariosJuecesDeUnEventoEspecificoSinRepeticiones() throws ComisarioException {
        Evento evento = new Evento("Voleibol", "2024-07-27", 12);
        Comisario comisario1 = new Comisario("12345678", "Juan Perez", 40, "Juez");
        Comisario comisario2 = new Comisario("87654321", "Maria Lopez", 30, "Juez");
        Comisario comisario3 = new Comisario("12345678", "Juan Perez", 40, "Juez");
        evento.agregarComisario(comisario1);
        evento.agregarComisario(comisario2);
        evento.agregarComisario(comisario3);
        assertEquals(2, evento.obtenerComisariosJueces().size());
    }

    @Test
    public void queSePuedaObtenerUnMapaDeUnComplejoPolideportivoConNombreDeComplejoYUbicacion() throws IndicadorAreaException {
        Polideportivo poli = new Polideportivo("Polideportivo F", 9000);
        Area area1 = new Area("Centro", 500);
        Area area2 = new Area("EsquinaNE", 600);
        poli.agregarArea(area1);
        poli.agregarArea(area2);
        Map<String, String> mapa = poli.obtenerMapaComplejo();
        assertEquals(2, mapa.size());
        assertEquals("Centro", mapa.get("Polideportivo F"));
    }
}
