package ar.edu.unlam.pb2.dominio;

public class Area {
    private String indicador;
    private double area;

    public Area(String indicador, double area) {
        this.indicador = indicador;
        this.area = area;
    }

    public String getIndicador() {
        return indicador;
    }

    public double getArea() {
        return area;
    }
}
