package ar.edu.unlam.pb2.dominio;

public abstract class ComplejoDeportivo {
    protected String nombre;
    protected double areaTotal;

    public ComplejoDeportivo(String nombre, double areaTotal) {
        this.nombre = nombre;
        this.areaTotal = areaTotal;
    }

    public String getNombre() {
        return nombre;
    }

    public double getAreaTotal() {
        return areaTotal;
    }
}
