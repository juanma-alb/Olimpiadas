package ar.edu.unlam.pb2.dominio;

public class ComisarioException extends Exception {
    public ComisarioException(String message) {
        super(message);
    }
}

