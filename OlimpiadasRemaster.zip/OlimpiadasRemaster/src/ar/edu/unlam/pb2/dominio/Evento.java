package ar.edu.unlam.pb2.dominio;

import java.util.*;

public class Evento {
    private String nombre;
    private String fecha;
    private int numeroParticipantes;
    private List<Comisario> comisarios;

    public Evento(String nombre, String fecha, int numeroParticipantes) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.numeroParticipantes = numeroParticipantes;
        this.comisarios = new ArrayList<>();
    }

    public void agregarComisario(Comisario comisario) throws ComisarioException {
        if (comisario == null) {
            throw new ComisarioException("Comisario inexistente");
        }
        this.comisarios.add(comisario);
    }

    public List<Comisario> getComisarios() {
        return comisarios;
    }

    public int getNumeroParticipantes() {
        return numeroParticipantes;
    }

    public double calcularPromedioEdadObservadores() {
        int totalEdad = 0;
        int contador = 0;
        for (Comisario comisario : comisarios) {
            if ("Observador".equals(comisario.getTipo())) {
                totalEdad += comisario.getEdad();
                contador++;
            }
        }
        return contador == 0 ? 0 : (double) totalEdad / contador;
    }

    public Set<Comisario> obtenerComisariosJueces() {
        Set<Comisario> jueces = new HashSet<>();
        for (Comisario comisario : comisarios) {
            if ("Juez".equals(comisario.getTipo())) {
                jueces.add(comisario);
            }
        }
        return jueces;
    }
}
