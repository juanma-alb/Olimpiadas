package ar.edu.unlam.pb2.dominio;

public class IndicadorAreaException extends Exception {
    public IndicadorAreaException(String message) {
        super(message);
    }
}
